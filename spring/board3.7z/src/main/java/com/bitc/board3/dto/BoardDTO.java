package com.bitc.board3.dto;

import lombok.Data;

@Data
public class BoardDTO {
    private int boardIdx;
    private String title;
    private String contents;
    private int hitCnt;
    private String createDate;
    private String createId;
    private String updateDate;
    private String updateId;

}
