package com.bitc.board3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Board3ApplicationTests {

    @Test
    void contextLoads() {
    }

}
